import glob
import os
import cv2
import numpy as np
import rasterio
import imageio
import torch

from ..utils import image_loader
from .semantic_segmentation import SemanticSegmentationDataset
from .schemas import TiiLIDARDatasetBinaryWithPreprocessingSchema

'''
    The new format of the file is as follows:
    Band 0 - barrow
    Band 1 - enclosure
    Band 2 - ringfort

    Each band is coded with the following values:
    0 - background
    1 - DFM = 1
    2 - DFM = 2
    3 - DFM = 3
    4 - DFM = 4
    5 - new object (Archaeological False Positive from the ML results analysis)
'''

class TiiLIDARDatasetSegmentation(SemanticSegmentationDataset):
    schema = TiiLIDARDatasetBinaryWithPreprocessingSchema
    url = ""

    labels = ["Background","AO"]
    color_mapping = [[0,0,0],[255, 255, 255]]
    name = "TII LIDAR Binary"

    def get_fixed_model_config():
        return {
            "num_classes": 2,
            "learning_rate": 0.0001,
            "pretrained": True,
            "use_cuda": torch.cuda.is_available(),
            "threshold": 0.5,
            "metrics": ["iou"]
    }
    
    def __init__(self, config):
        # now call the constructor to validate the schema and split the data
        super().__init__(config)
        self.images = []
        self.masks = []
        self.load_dataset(self.config.data_dir)

    def __getitem__(self, index):
        with rasterio.open(self.images[index]) as image_tiff:
            image = image_tiff.read()
        if image.shape[0] == 1:
            image = np.repeat(image, 3, axis=0)
        image = np.transpose(image, (1, 2, 0))
        mask = self.process_single_mask(self.masks[index], self.DFM_quality, self.object_class, self.object_class_band_id)
        masks = [(mask == v) for v, label in enumerate(self.labels)]
        mask = np.stack(masks, axis=-1).astype("float32")
        return self.apply_transformations(image, mask)
    
    def should_include_mask(self, mask_path, DFM_setting, keep_empty_patches, object_class, object_class_band_id):
        if(keep_empty_patches):
            return True
        else:
            mask = imageio.imread(mask_path)
            # Check if transpose is necessary
            if mask.ndim == 3 and mask.shape[0] == 3:
                mask = np.transpose(mask, (1, 2, 0))
            mask = np.isin(mask, DFM_setting).astype(np.uint8)
            if (object_class!='AO'):
                mask = mask[:,:,object_class_band_id] # filter object_class
            else: 
                mask = np.squeeze(np.max(mask, axis=2, keepdims=True))
            return not np.all(mask == 0)
        
    
    def process_single_mask(self, mask_path, DFM_setting, object_class, object_class_band_id):
        mask = imageio.imread(mask_path)
        # Check if transpose is necessary
        if mask.ndim == 3 and mask.shape[0] == 3:
            mask = np.transpose(mask, (1, 2, 0))
        mask = np.isin(mask, DFM_setting).astype(np.uint8)
        if (object_class!='AO'):
            mask = mask[:,:,object_class_band_id] # filter object_class
        else:
            mask = np.squeeze(np.max(mask, axis=2, keepdims=True))
        return mask
        
    def load_dataset(self, data_dir):
        self.object_class = self.config.object_class
        self.object_class_band_id = self.config.object_class_band_id
        self.DFM_quality = [int(item) for item in self.config.DFM_quality.split(',')]
        self.keep_empty_patches = self.config.keep_empty_patches
        annotations_dir = self.config.annotations_dir
        for mask_filename in os.listdir(annotations_dir):
            if (mask_filename.endswith(".tif")):
                image_path = f'{data_dir}/{mask_filename.split("__")[0]}__{mask_filename.split("__")[1]}__{self.config.visualisation_type}.tif'
                if (os.path.isfile(image_path) and 
                    os.path.isfile(os.path.join(annotations_dir, mask_filename)) and 
                    self.should_include_mask(os.path.join(annotations_dir, mask_filename), self.DFM_quality, self.keep_empty_patches, self.object_class, self.object_class_band_id)) :
                    mask_path = os.path.join(annotations_dir, mask_filename)
                    self.masks.append(mask_path)
                    self.images.append(image_path)


