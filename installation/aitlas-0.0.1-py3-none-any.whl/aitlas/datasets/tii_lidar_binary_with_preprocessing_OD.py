import os
from os.path import exists, join
from .object_detection import ObjectDetectionCocoDataset
from .schemas import ObjectDetectionCocoDatasetTIIDatasetSchema
import rasterio
from datetime import datetime
import numpy as np
import json
import torch

class TiiLIDARDatasetObjectDetection(ObjectDetectionCocoDataset):
    schema = ObjectDetectionCocoDatasetTIIDatasetSchema

    def get_fixed_model_config():
        return {
            "num_classes": 2,
            "learning_rate": 0.0001,
            "pretrained": True,
            "use_cuda": torch.cuda.is_available(),
            "metrics": ["map"]
        }

    def __init__(self, config):
        self.config = config
        self.config['hardcode_background'] = False
        self.data_dir = config['data_dir']
        self.annotations_dir = config['annotations_dir']
        self.DFM_quality = config['DFM_quality']
        self.visualisation_type = config['visualisation_type']
        self.object_class = config['object_class']
        self.keep_empty_patches = False
        coco_json_path = self.create_coco_json(self.data_dir, self.annotations_dir, self.DFM_quality, self.visualisation_type, [self.object_class], self.keep_empty_patches)
        self.config['json_file'] = coco_json_path
        super().__init__(self.config)

    def get_label_info(self, line):
        line_parts = line.split(' ')
        return int(line_parts[0]), int(line_parts[1]), int(line_parts[2]), int(line_parts[3]), int(line_parts[4]), int(line_parts[5]), int(line_parts[6]), int(line_parts[7]), line_parts[8] , int(line_parts[9]), line_parts[10], line_parts[11],  line_parts[12]




    def create_coco_json(self, data_dir, annotations_dir, DFM_quality, visualisation_type, categories, keep_empty_patches):
        if categories[0] == 'AO':
            categories_list = [
                {"id": 1, "name": "AO"},
            ]
            categories_dict = {"AO": 1}
        else: 
            categories_list = []
            categories_dict = {}
            for category in categories:
                categories_list.append({"id": categories.index(category)+1, "name": category})
                categories_dict[category] = categories.index(category)+1
        
        images_list = []
        annotations_list = []
        for image_file_name in os.listdir(data_dir):
            image_file_path = join(data_dir, image_file_name)
            if image_file_path.endswith(f"__{visualisation_type}.tif"):
                annotations_file_name = image_file_name.replace(visualisation_type+".tif", "labelTxt.txt")
                annotations_file_path  = join(annotations_dir, annotations_file_name)

                image_id = len(images_list) + 1
                if exists(annotations_file_path) and exists(image_file_path):
                    image_added_flag = False
                    with rasterio.open(image_file_path) as image_tiff:
                        image = image_tiff.read()                    
                    size_in_px = image.shape[1]
                    with open (annotations_file_path) as f:
                        lines = f.readlines()
                        for line in lines:
                            x1, y1, x2, y2, x3, y3, x4, y4, label, DFM, TRUN, EDGE, EDGE_P =  self.get_label_info(line)
                            x_min = min([x1,x2,x3,x4])
                            x_max = max([x1,x2,x3,x4])
                            y_min = min([y1,y2,y3,y4])
                            y_max = max([y1,y2,y3,y4])

                            if y_max == size_in_px:
                                y_max = y_max - 1 
                            if x_max == size_in_px:
                                x_max = x_max - 1
                            if y_max <= y_min:
                                continue
                            coco_url = image_file_path
                            if keep_empty_patches:
                                if not image_added_flag:
                                    images_list.append({
                                        "id": image_id,
                                        "coco_url": coco_url,
                                        "width": size_in_px,
                                        "height": size_in_px,
                                        "file_name": image_file_name,
                                        "data_captured": "2022-01-01 00:01:00"
                                    })
                                    image_added_flag = True

                            if ((label in categories or categories[0] == "AO") and (str(DFM) in DFM_quality.split(','))):
                                if not image_added_flag:
                                    images_list.append({
                                        "id": image_id,
                                        "coco_url": coco_url,
                                        "width": size_in_px,
                                        "height": size_in_px,
                                        "file_name": image_file_name,
                                        "data_captured": "2022-01-01 00:01:00"
                                    })
                                    image_added_flag = True
                                bbox = [x_min, y_min, x_max-x_min, y_max-y_min]
                                annotations_list.append({
                                    "image_id":  image_id,
                                    "category_id": 1 if categories[0] == 'AO' else categories_dict[label],
                                    "bbox": bbox
                                })
                                

                else:
                    print("Error in input data: ", image_file_path, ". Check of both the image and the annotations file are provided. ")

        dataset_dict = {
            'info': {},
            'categories': categories_list, 
            'images': images_list, 
            'annotations': annotations_list
        }
        # Create the directory if it does not exist
        coco_jsons_dir = f"{annotations_dir}/coco_jsons"
        if not os.path.exists(coco_jsons_dir):
            os.makedirs(coco_jsons_dir)

        # Generate a timestamp for the filename
        timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        filename = f"{coco_jsons_dir}/{timestamp}.json"

        # Write the dataset dictionary to a JSON file with the timestamped filename
        with open(filename, "w") as write_file:
            json.dump(dataset_dict, write_file, indent=4)

        return filename

    